const socket = io("localhost:4000");
let imageSection = document.getElementById('images');
let demoDiv = document.createElement("h3");
let registration = {
    fullname: "",
    email: "",
    pass: "",
    phone: "",
    address: "",
    pin: ""
};

let login = {
    user: "",
    pass: ""
};

function handleClick() {
    socket.emit('registration', registration);
}

function handleLogin() {
    socket.emit('login', login);
}

function handleChange(id, val) {
    switch (id) {
        case "fullName":
            data.fullname = val;
            break;
        case "email":
            data.email = val;
            break;
        case "password":
            data.pass = val;
            break;
        case "phone":
            data.phone = val;
            break;
        case "address":
            data.address = val;
            break;
        case "pin":
            data.pin = val;
            break;
        case "Username":
            login.user = val;
            break;
        case "Userpass":
            login.pass = val;
            break;
    }
}



socket.on("cakeData", (datas) => {
    datas.map((data) => {
        let indiImage = document.createElement('div');
        let img = document.createElement('img')
        img.alt = "img";
        let entityName = document.createElement("h2");
        // console.log(data)
        entityName.innerHTML = data.cakeName;
        img.src = data.cakePath;
        indiImage.appendChild(img);
        indiImage.appendChild(entityName);
        demoDiv.appendChild(indiImage);
    });
});
imageSection.appendChild(demoDiv)